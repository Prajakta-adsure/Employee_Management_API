﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Mini_Project.Models;
namespace WebApplication1.Models
{
    public class Appdbcontext : DbContext
    {

        public Appdbcontext(DbContextOptions<Appdbcontext> options)
                 : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseMySQL(@"Server=localhost;User ID=root;Password=Anita@16;Database=caddey1");
            }
        }
        public DbSet<Employee> Employees { get; set; }
    }

}

